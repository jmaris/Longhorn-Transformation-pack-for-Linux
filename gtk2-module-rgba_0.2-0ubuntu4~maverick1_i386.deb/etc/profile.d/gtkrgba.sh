export GTK_MODULES=rgba
export GTK_RGBA_APPS=allbut:firefox:firefox-3.5:gksudo:ooffice:soffice:inksca\
pe:gksu:gtk-recordMyDesktop:kompozer-bin:gpaint:lernid:truecrypt:thunderbird-\
bin:thunderbird:checkgmail:gloobus-preview:exe:firefox-bin:swiftfox-bin:gnome\
-mplayer:gnome-screensaver:google-chrome:chromium-browser:prism-bin:gnome-mpl\
ayer:xsane:metacity:mutter:Banshee
